// OTP implementation WIP - example code from article below:
// dev.to/manthanank/building-an-otp-verification-system-with-nodejs-and-mongodb-2p0o

const express = require('express');
const {sendOTP, verifyOP} = require('../controllers/otpController');

const router = express.router();

router.get('sendOTP', sendOTP);
router.get('verifyOTP', verifyOTP);

module.exports = router;