// OTP implementation WIP - example code from article below:
// dev.to/manthanank/building-an-otp-verification-system-with-nodejs-and-mongodb-2p0o

const mongoose = require('mongoose');

const otpSchema = new mongoose.mongoose.Schema({
email : {type: String, required: true},
otp: {type: String, required: true},

});

const Otps = mongoose.model('otps', otpSchema);

module.exports = Otps;